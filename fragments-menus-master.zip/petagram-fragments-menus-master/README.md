# petagram-fragments-menus
**Incluyendo fragments y menus en una  app**
<br/><br/>
<img src="https://github.com/InvedAllens/petagram-fragments-menus/blob/master/Screenshots/fragments.gif" width="300"/>
---
*Caracteristicas*
- La lista de objetos se muestra en un recycler view en la actividad principal y en la de favoritos
- Los ultimos 5 elementos que se les ha dado "like" se muestran en una actividad de favoritos
- Modularizacion en fragments en la actividad principal
- Envio de mail con la libreria jmail
- Uso de menus
<br/>
				<img src="https://github.com/InvedAllens/petagram-fragments-menus/blob/master/Screenshots/Screenshot2.jpg" alt="drawing" width="300"/>
<br/>
				<img src="https://github.com/InvedAllens/petagram-fragments-menus/blob/master/Screenshots/Screenshot3.jpg" alt="drawing" width="300"/>
<br/>
				<img src="https://github.com/InvedAllens/petagram-fragments-menus/blob/master/Screenshots/Screenshot4.jpg" alt="drawing" width="300"/>
<br/>
				<img src="https://github.com/InvedAllens/petagram-fragments-menus/blob/master/Screenshots/Screenshot5.jpg" alt="drawing" width="300"/>
<br/>

<a href='https://www.freepik.es/fotos-vectores-gratis/perro'>Vector de Perro creado por freepik - www.freepik.es</a>
<a href="https://www.freepik.es/fotos-vectores-gratis/perro">Vector de Perro creado por freepik - www.freepik.es</a>
<a href="https://www.freepik.com/free-photos-vectors/avatar">Avatar vector created by freepik - www.freepik.com</a>




